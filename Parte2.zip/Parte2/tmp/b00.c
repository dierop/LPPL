// Ejemplo con errores lexicos: 1 error
{
  int  aAa123_2016 = 0;
  int c#;                         // caracter desconocido

  c = (((aAa123_2016 % 2) - 3.56) * .34) / 2.;
}
